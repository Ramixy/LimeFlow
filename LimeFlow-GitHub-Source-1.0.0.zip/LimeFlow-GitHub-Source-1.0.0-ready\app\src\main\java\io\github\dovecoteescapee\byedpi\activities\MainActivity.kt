package io.github.dovecoteescapee.byedpi.activities

import android.Manifest
import android.animation.ValueAnimator
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.lifecycleScope
import io.github.dovecoteescapee.byedpi.R
import io.github.dovecoteescapee.byedpi.data.*
import io.github.dovecoteescapee.byedpi.databinding.ActivityMainBinding
import io.github.dovecoteescapee.byedpi.services.ServiceManager
import io.github.dovecoteescapee.byedpi.services.appStatus
import io.github.dovecoteescapee.byedpi.utility.*
import com.google.android.material.color.MaterialColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var powerAnimator: ValueAnimator? = null
    private var logoAnimator: ObjectAnimator? = null
    private var lastPowerState: Boolean? = null

    companion object {
        private val TAG: String = MainActivity::class.java.simpleName

        private fun collectLogs(): String? =
            try {
                Runtime.getRuntime()
                    .exec("logcat *:D -d")
                    .inputStream.bufferedReader()
                    .use { it.readText() }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to collect logs", e)
                null
            }
    }

    private val vpnRegister =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                ServiceManager.start(this, Mode.VPN)
            } else {
                Toast.makeText(this, R.string.vpn_permission_denied, Toast.LENGTH_SHORT).show()
                updateStatus()
            }
        }

    private val logsRegister =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            lifecycleScope.launch(Dispatchers.IO) {
                val logs = collectLogs()

                if (logs == null) {
                    Toast.makeText(
                        this@MainActivity,
                        R.string.logs_failed,
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    val uri = it.data?.data ?: run {
                        Log.e(TAG, "No data in result")
                        return@launch
                    }
                    contentResolver.openOutputStream(uri)?.use {
                        try {
                            it.write(logs.toByteArray())
                        } catch (e: IOException) {
                            Log.e(TAG, "Failed to save logs", e)
                        }
                    } ?: run {
                        Log.e(TAG, "Failed to open output stream")
                    }
                }
            }
        }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d(TAG, "Received intent: ${intent?.action}")

            if (intent == null) {
                Log.w(TAG, "Received null intent")
                return
            }

            val senderOrd = intent.getIntExtra(SENDER, -1)
            val sender = Sender.entries.getOrNull(senderOrd)
            if (sender == null) {
                Log.w(TAG, "Received intent with unknown sender: $senderOrd")
                return
            }

            when (val action = intent.action) {
                STARTED_BROADCAST,
                STOPPED_BROADCAST -> updateStatus()

                FAILED_BROADCAST -> {
                    Toast.makeText(
                        context,
                        getString(R.string.failed_to_start, sender.name),
                        Toast.LENGTH_SHORT,
                    ).show()
                    updateStatus()
                }

                else -> Log.w(TAG, "Unknown action: $action")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applyStoredTheme()
        super.onCreate(savedInstanceState)

        installAlt11Defaults()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        animateScreenEntry()

        val intentFilter = IntentFilter().apply {
            addAction(STARTED_BROADCAST)
            addAction(STOPPED_BROADCAST)
            addAction(FAILED_BROADCAST)
        }

        @SuppressLint("UnspecifiedRegisterReceiverFlag")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, intentFilter, RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, intentFilter)
        }

        binding.statusButton.setOnClickListener {
            val (status, _) = appStatus
            when (status) {
                AppStatus.Halted -> start()
                AppStatus.Running -> stop()
            }
        }
        binding.statusButtonCard.setOnClickListener { binding.statusButton.performClick() }
        binding.strategyButton.setOnClickListener { openProfiles() }
        binding.profilesButton.setOnClickListener { openProfiles() }
        binding.themeIconButton.setOnClickListener {
            it.animate().rotationBy(90f).setDuration(260).start()
            cycleTheme()
        }
        binding.themeIconButton.setOnLongClickListener {
            showThemePicker()
            true
        }
        binding.settingsIconButton.setOnClickListener { openSettings() }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun installAlt11Defaults() {
        val preferences = getPreferences()
        if (preferences.getInt("limeflow_engine_version", 0) >= 7) return

        preferences.edit()
            .putString("byedpi_mode", "vpn")
            .putBoolean("byedpi_enable_cmd_settings", true)
            .putBoolean("ipv6_enable", true)
            .putBoolean("alt11_defaults_installed", true)
            .putInt("limeflow_engine_version", 7)
            .apply()
        FlowsealProfiles.select(preferences, FlowsealProfiles.selected(preferences))
    }

    override fun onResume() {
        super.onResume()
        val profile = FlowsealProfiles.selected(getPreferences())
        binding.strategyButtonText.text = getString(
            R.string.profile_summary,
            profile.name,
            profile.method,
        )
        updateStatus()
    }

    private fun openProfiles() {
        val (status, _) = appStatus
        if (status == AppStatus.Running) {
            Toast.makeText(this, R.string.stop_before_strategy, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, ProfilePickerActivity::class.java))
    }

    private fun showThemePicker() {
        val values = arrayOf("system", "light", "dark")
        val labels = arrayOf(
            getString(R.string.theme_system),
            getString(R.string.theme_light),
            getString(R.string.theme_dark),
        )
        val current = getPreferences().getString("app_theme", "system") ?: "system"
        AlertDialog.Builder(this)
            .setTitle(R.string.theme)
            .setSingleChoiceItems(labels, values.indexOf(current).coerceAtLeast(0)) { dialog, which ->
                getPreferences().edit().putString("app_theme", values[which]).apply()
                dialog.dismiss()
                applyStoredTheme()
            }
            .show()
    }

    private fun cycleTheme() {
        val preferences = getPreferences()
        val current = preferences.getString("app_theme", "system") ?: "system"
        val next = when (current) {
            "system" -> "dark"
            "dark" -> "light"
            else -> "system"
        }
        preferences.edit().putString("app_theme", next).apply()
        applyStoredTheme()
        Toast.makeText(
            this,
            when (next) {
                "dark" -> R.string.theme_dark
                "light" -> R.string.theme_light
                else -> R.string.theme_system
            },
            Toast.LENGTH_SHORT,
        ).show()
    }

    private fun openSettings() {
        val (status, _) = appStatus
        if (status == AppStatus.Halted) {
            startActivity(Intent(this, SettingsActivity::class.java))
        } else {
            Toast.makeText(this, R.string.settings_unavailable, Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyStoredTheme() {
        val mode = when (getPreferences().getString("app_theme", "system")) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    override fun onDestroy() {
        powerAnimator?.cancel()
        logoAnimator?.cancel()
        super.onDestroy()
        unregisterReceiver(receiver)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val (status, _) = appStatus

        return when (item.itemId) {
            R.id.action_settings -> {
                if (status == AppStatus.Halted) {
                    val intent = Intent(this, SettingsActivity::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, R.string.settings_unavailable, Toast.LENGTH_SHORT)
                        .show()
                }
                true
            }

            R.id.action_save_logs -> {
                val intent =
                    Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TITLE, "limeflow.log")
                    }

                logsRegister.launch(intent)
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun start() {
        when (getPreferences().mode()) {
            Mode.VPN -> {
                val intentPrepare = VpnService.prepare(this)
                if (intentPrepare != null) {
                    vpnRegister.launch(intentPrepare)
                } else {
                    ServiceManager.start(this, Mode.VPN)
                }
            }

            Mode.Proxy -> ServiceManager.start(this, Mode.Proxy)
        }
    }

    private fun stop() {
        ServiceManager.stop(this)
    }

    private fun updateStatus() {
        val (status, mode) = appStatus

        Log.i(TAG, "Updating status: $status, $mode")

        val preferences = getPreferences()
        val proxyIp = preferences.getStringNotNull("byedpi_proxy_ip", "127.0.0.1")
        val proxyPort = preferences.getStringNotNull("byedpi_proxy_port", "1080")
        binding.proxyAddress.text = getString(R.string.proxy_address, proxyIp, proxyPort)

        when (status) {
            AppStatus.Halted -> {
                when (preferences.mode()) {
                    Mode.VPN -> {
                        binding.statusText.setText(R.string.vpn_disconnected)
                        binding.statusButton.setText(R.string.vpn_connect)
                    }

                    Mode.Proxy -> {
                        binding.statusText.setText(R.string.proxy_down)
                        binding.statusButton.setText(R.string.proxy_start)
                    }
                }
                binding.statusButton.isEnabled = true
            }

            AppStatus.Running -> {
                when (mode) {
                    Mode.VPN -> {
                        binding.statusText.setText(R.string.vpn_connected)
                        binding.statusButton.setText(R.string.vpn_disconnect)
                    }

                    Mode.Proxy -> {
                        binding.statusText.setText(R.string.proxy_up)
                        binding.statusButton.setText(R.string.proxy_stop)
                    }
                }
                binding.statusButton.isEnabled = true
            }
        }
        updatePowerColor(status == AppStatus.Running)
    }

    private fun updatePowerColor(active: Boolean) {
        if (lastPowerState == active) return

        val current = binding.statusButtonCard.cardBackgroundColor.defaultColor
        val target = if (active) {
            ContextCompat.getColor(this, R.color.lime_connected)
        } else {
            MaterialColors.getColor(binding.root, com.google.android.material.R.attr.colorPrimary)
        }
        powerAnimator?.cancel()

        if (lastPowerState == null) {
            binding.statusButtonCard.setCardBackgroundColor(target)
        } else {
            val middle = ColorUtils.blendARGB(current, target, 0.5f)
            powerAnimator = ValueAnimator.ofArgb(current, middle, target).apply {
                duration = 850
                interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener {
                    binding.statusButtonCard.setCardBackgroundColor(it.animatedValue as Int)
                }
                start()
            }
            binding.statusButtonCard.animate()
                .scaleX(1.06f)
                .scaleY(1.06f)
                .setDuration(260)
                .withEndAction {
                    binding.statusButtonCard.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(320)
                        .start()
                }
                .start()
        }
        lastPowerState = active
    }

    private fun animateScreenEntry() {
        binding.root.alpha = 0f
        binding.root.animate().alpha(1f).setDuration(360).start()
        listOf(binding.heroBackground, binding.bottomActions).forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationY = 34f
            view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(90L + index * 80L)
                .setDuration(420)
                .start()
        }
        logoAnimator = ObjectAnimator.ofFloat(binding.brandLogo, View.TRANSLATION_Y, 0f, -5f).apply {
            duration = 1_600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }
}
